# ARMLIB (Keil-MDK) porting for RT-Thread

https://www.keil.com/support/man/docs/armlib/

https://www.keil.com/support/man/docs/armlib/armlib_chr1358938918041.htm