This folder contains:

| sub-folders | description               |
| ----------- | ------------------------- |
| aio         | Asynchronous I/O          |
| mman        | Memory-Mapped I/O         |
| poll        | Nonblocking I/O           |
| stdio       | Standard Input/Output I/O |
| termios     | Terminal I/O              |

