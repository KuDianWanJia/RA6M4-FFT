/* generated configuration header file - do not edit */
#ifndef R_ELC_CFG_H_
#define R_ELC_CFG_H_
#define ELC_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* R_ELC_CFG_H_ */
